package com.example;

import com.fire.block.BlockRegistry;

public final class ModRuby {

    private ModRuby() {}

    public static void register() {
        BlockRegistry.register(
                "ruby",
                "/assets/myfirstmod/textures/block/ruby.png"
        );
    }
}