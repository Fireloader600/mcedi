package com.example;

import com.fire.block.BlockRegistry;
import com.fire.mod.EdiMod;
import com.fire.world.WorldTag;

public class ModBlock implements EdiMod {

    @Override
    public void onInit(BlockRegistry registry) {
        //block register
        ModRuby.register();
    }

    @Override
    public void onWorldTag(WorldTag tag) {
        //biome register
    }
}